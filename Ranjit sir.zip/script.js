document.querySelectorAll('.award').forEach(item => {
  item.addEventListener('click', () => {
    alert('यह सम्मान कवि रंजीत तिवारी जी को प्राप्त हुआ है।');
  });
});